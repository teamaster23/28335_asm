#ifndef _FLASH28335_LEAVECMDMODE_TEST_H_
#define _FLASH28335_LEAVECMDMODE_TEST_H_
#include <stdint.h>

void Fl28x_LeaveCmdMode_test(void);

#endif // _FLASH28335_LEAVECMDMODE_TEST_H_