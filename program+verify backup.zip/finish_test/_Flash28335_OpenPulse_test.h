#ifndef _FLASH28335_OPENPULSE_TEST_H_
#define _FLASH28335_OPENPULSE_TEST_H_
#include <stdint.h>

uint16_t Fl28x_OpenPulse_test(uint32_t acc);

#endif
