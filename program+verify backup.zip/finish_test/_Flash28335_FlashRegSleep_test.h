#ifndef FL28X_FlashRegSleep_TEST
#define FL28X_FlashRegSleep_TEST

#include <stdint.h>

void Fl28x_FlashRegSleep_test(void);

#endif // FL28X_FlashRegSleep_TEST