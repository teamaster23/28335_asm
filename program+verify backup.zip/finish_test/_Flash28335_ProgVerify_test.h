#ifndef _FLASH28335_PROGVERIFY_TEST_H_
#define _FLASH28335_PROGVERIFY_TEST_H_
#include <stdint.h>

uint16_t Fl28x_ProgVerify_test(uint16_t sector, uint32_t addr);
#endif