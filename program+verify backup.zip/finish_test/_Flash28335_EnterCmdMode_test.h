#ifndef _FLASH28335_ENTERCMDMODE_TEST_H_
#define _FLASH28335_ENTERCMDMODE_TEST_H_

#include <stdint.h>

void Fl28x_EnterCmdMode_test(void);

#endif // _FLASH28335_ENTERCMDMODE_TEST_H_