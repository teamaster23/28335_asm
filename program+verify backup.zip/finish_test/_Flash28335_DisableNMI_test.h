#ifndef _FLASH28335_DISABLENMI_TEST_H_
#define _FLASH28335_DISABLENMI_TEST_H_
#include<stdint.h>

uint16_t Fl28x_DisableNMI_test(void);

#endif
