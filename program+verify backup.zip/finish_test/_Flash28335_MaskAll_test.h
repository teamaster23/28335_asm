#ifndef FL28X_MASKALL_TEST_H
#define FL28X_MASKALL_TEST_H
#include <stdint.h>
void Fl28x_MaskAll_test(void);
#endif
