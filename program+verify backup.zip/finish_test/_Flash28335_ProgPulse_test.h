#ifndef _FLASH28x_PROGPULSE_TEST_H_
#define _FLASH28x_PROGPULSE_TEST_H_
#include <stdint.h>
void Fl28x_ProgPulse_test(uint32_t acc, uint16_t ar4, uint16_t ar5);
#endif